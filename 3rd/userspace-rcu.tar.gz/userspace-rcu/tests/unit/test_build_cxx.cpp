/* SPDX-License-Identifier: GPL-2.0-or-later */

#include "test_build.c"
